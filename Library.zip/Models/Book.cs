﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Library.Models
{
    public class Book
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("BookType")]
        public int BookTypeId { get; set; }
        public virtual BookType BookType { get; set; }

        [Required]
        public string Name { get; set; }

        public short TotalQty { get; set; }

        public short AvailableQty { get; set; }

    }
}
